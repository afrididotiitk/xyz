
# Conditionals
# a = 5
# b = 5
# c = 9
# if a == b:
# 	print "a=b"
# elif b < c and a < c:
# 	print "c is largest"
# else:
# 	print "no condition satisfied"

# Loops
#for i in range(0,10):
#	print i

#lst = ["welcome", "to", "cs" , 251, {'a':1, 10: '5'}]

# for content in lst:
# 	print content
# 	if isinstance(content, dict):
# 		for key in content:
# 			print key, content[key]

# lst = []
# dic = {}
# i = 0
# j = 1
# c = 1
# while True:
# 	k = i + j
# 	if k > 100:
# 		break
# 	lst.append(k)
# 	dic[c] = k
# 	c += 1
# 	i = j
# 	j = k
	
# print lst
# print dic

