dlmread('test.csv',',',1,0)
