#include<common.h>
static int help()
{
   return 0;
}
