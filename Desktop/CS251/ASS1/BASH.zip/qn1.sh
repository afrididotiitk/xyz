#!/bin/bash

extract(){
            local directory=$1
            local comment=0
            local string=0
    for files in "$directory"/*

        do 

            if [ -f "$files" ];
            then 
                
                if [[ "${files##*\.}" =~ "c" ]];
                then 
                            local V=`awk -f qn1.awk "$files"`
                            local comment1=`echo "$V"|awk '{print $1}'`
                            local string1=`echo "$V"|awk '{print $2}'`            
                            comment=$(($comment+$comment1))
                            string=$(($string+$string1))
                fi
            else 
                if [ -d "$files" ];
                then 
                            local V=`extract "$files"`  
                            local comment1=`echo "$V"|awk '{print $1}'`
                            local string1=`echo "$V"|awk '{print $2}'`
                            comment=$(($comment+$comment1))
                            string=$(($string+$string1))
                fi
            fi
        done


             echo -e "$comment\t$string"
}
directory=$1

            if [[ -d "$directory" ]];
            then
            q=`extract "$directory"`
            comment=`echo "$q"|awk '{print $1}'`
            string=`echo "$q"|awk '{print $2}'`
                echo "$string string"
                echo "$comment lines of comment"
                
            else
            echo "invlaid input"
exit 1
fi
