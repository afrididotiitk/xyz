#include <stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include<fcntl.h>
#include<pthread.h>
#include<string.h>
#define MAX_THREADS 64
#define START_INDEX 1001
#define SIZE 10000
#define USAGE_EXIT(s) do{ \
                             printf("Usage: %s <acc_file.txt> <txn_file.txt> <# of txns> <# of threads> \n %s\n", argv[0], s); \
                            exit(-1);\
                    }while(0);

#define TDIFF(start, end) ((end.tv_sec - start.tv_sec)*1000000UL + (end.tv_usec - start.tv_usec))

typedef struct account{
	double bal;
	struct trans *txn;
}acc;


typedef struct trans{
	int type;
        double amount;
	struct trans *nexttxn;
}trxn;

struct thread_param{//thread related parameters.
  pthread_t tid;
  acc *accnt;
  int skip;
  int i;
};

void update_acc(acc *acn,trxn *trans,int transid){
	if ( trans == NULL)
		return;
	else
	{
		acc *current = acn + transid;
		if ( trans->type == 1)
			current->bal = current->bal + 0.99*((trans->amount));
		else if ( trans->type == 2)
			current->bal = current->bal - 1.01*((trans->amount));
		else if ( trans->type == 3)
			current->bal = (current->bal)*1.071;	
	}
	update_acc(acn, trans->nexttxn, transid);
	return;
}

void update(acc *ac,int index)
{
    update_acc(ac,(ac+index)->txn,index);
    return;

}
void* updateone(void *arg)
{
    struct thread_param *params =(struct thread_param *) arg;
    int skip=params->skip;
    int  i = params->i;
    for(int j = i;j < 10000; j+= skip)
    {
      update(params->accnt,j);
      
    }
    return NULL;
}

void insert(acc *acn,int source_id,int dest_id,int type,double amount)
{ if(acn != NULL)
  { 
   
    if(type > 0 && type < 4)
    {
        trxn *current =  (acn+source_id)->txn;
        trxn *new=(trxn *) malloc(sizeof(trxn));
        new->nexttxn=NULL;
        new->amount=amount;
        new->type=type;   
        type = 0; 
        if(current == NULL)
        {
          (acn+source_id)->txn = new;
          return;
        }   
        else
        {
          while(current->nexttxn!=NULL)
          {
            current = current->nexttxn;
          }
          current->nexttxn = new;
          return;          
         }
    }
    else if(type == 4)
    {
        insert(acn,source_id,dest_id,2,amount);
        insert(acn,dest_id,source_id,1,amount);
        return;
    }
  }
  return;
}


int main ( int argc, char **argv){

        struct timeval start, end;

        int num_elements = argc;
        if(argc != 5){
           printf("not enough parameters\n");
           exit(-1);
        }
        int num_transactions = atoi(argv[3]);
	if(num_transactions <= 0){
		printf("Transactions not applicable\n");	
	}
        if(num_elements <=0){
          printf("invalid num elements\n");
          exit(-1);
        }
        int num_threads = atoi(argv[4]);
        if(num_threads <=0 || num_threads > MAX_THREADS){
          printf("invalid num of threads\n");
          exit(-1);
        }


        FILE *acct = fopen(argv[1], "r");
        if ( !acct ){
              printf("Error! Could not open file\n");
              exit(-1);
        }

	acc *raccount = (acc *)malloc(SIZE*sizeof(acc));

        for( int i = 0; i < 10000; i++){
		int acc_id;
		double balance;
              fscanf(acct, "%d %lf\n", &acc_id, &balance);
	       (raccount + i)->bal = balance;
               
        }
        fclose(acct);

        FILE*trans = fopen(argv[2], "r");
        if ( !trans){
              printf("Error! Could not open file\n");
              exit(-1);
        }
        for ( int i = 0; i < num_transactions; i++){
	      	int tseq, type, acc1, acc2;
		double amount;
              	fscanf(trans, "%d %d %lf %d %d\n", &tseq, &type, &amount, &acc1, &acc2);
		insert(raccount, acc1 - 1001, acc2 - 1001, type, amount);
        }
        fclose(trans);

	 struct thread_param *params;
    	params = malloc(num_threads*sizeof(struct thread_param));
   	bzero(params,num_threads*sizeof(struct thread_param));


        gettimeofday(&start, NULL);

        for ( int j = 0; j < num_threads; j++){
		(params+j)->skip=num_threads;
      		(params+j)->accnt = raccount;
      		(params+j)->i = j;
                if(pthread_create(&(params+j)->tid, NULL, updateone, params+j)){
                        perror("Unable to create thread");
                        exit(-1);
                }
        }

        for ( int j = 0; j < num_threads; j++){
		struct thread_param*paramj = params + j;
   		pthread_join(paramj->tid,NULL);
	}   

        gettimeofday(&end , NULL);
        // update_acc(balance, transactions, num_transactions);
 
        printf("Time taken = %ld microsecs\n", TDIFF(start, end));

	FILE*update = fopen("final_acc.txt","w");
 	for(int i = 0; i< SIZE;i++)
 		{
   			fprintf(update,"%d %.2lf\n",(i+1001),(raccount+i)->bal);
		 }
 	fclose(update);
        free(raccount);
	free(params);
}
