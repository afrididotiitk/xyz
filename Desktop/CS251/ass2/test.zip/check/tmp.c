//"adfai"
/* This is a multi-line comment */
/* This is another
 multi-line "comment"
 considered as 4 lines
 */
int main()
{
return 0;
}
int solution(void)
{
 char *s = "try combinations of strings and /*comments*/ too"; //afjhasdkjfhakjfhg
 return 0;
}
